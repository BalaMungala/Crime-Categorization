package example

import org.apache.spark.SparkContext
import org.apache.spark.SparkContext._
import org.apache.spark.SparkConf
import org.apache.spark.sql.SQLContext

object SparkSetup {

  var sc: SparkContext = null

  var sqlc: SQLContext = null

  var sparkConf: SparkConf = null

  def initialize(): Unit = {
    sparkConf = new SparkConf().setMaster("local[2]").setAppName("Crime_Categorization")

    sc = new SparkContext(sparkConf)

    sqlc = new SQLContext(sc)

  }

}