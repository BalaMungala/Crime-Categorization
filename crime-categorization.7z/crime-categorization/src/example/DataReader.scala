package example


import org.apache.spark.SparkContext
import org.apache.spark.SparkContext._
import org.apache.spark.SparkConf
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.types._
import org.apache.spark.sql._

class DataReader {
	SparkSetup.initialize()
	val sqlc = SparkSetup.sqlc
	import sqlc.implicits._

	def readTrainingData(path :String) : DataFrame ={
		val input = SparkSetup.sc.textFile(path)
		val split = input.map( x => x.split(",(?=([^\"]*\"[^\"]*\")*[^\"]*$)", -1 ))
		val header = split.first()
		
		val rdds = split.filter(x => x(0) != header(0))

		val schema = StructType( List( 
					StructField( "Dates",StringType,true),
					StructField( "Category",StringType,true),
					StructField( "Descript",StringType,true),
					StructField( "DayOfWeek",StringType,true),
					StructField( "PdDistrict",StringType,true),
					StructField( "Resolution",StringType,true),
					StructField( "Address",StringType,true),
					StructField( "X",DoubleType,true),
					StructField( "Y",DoubleType,true)
		))

		val train = rdds.map(x => Row(x(0) , x(1), x(2), x(3) , x(4), x(5),x(6) , x(7).toDouble, x(8).toDouble ) ) 

		val df = sqlc.createDataFrame(train, schema)
		
		df
	}

	def readTestData(path :String) : DataFrame ={
		val input = SparkSetup.sc.textFile(path)
		val split = input.map( x => x.split(",(?=([^\"]*\"[^\"]*\")*[^\"]*$)", -1))
		
		//plit(",(?=([^\"]*\"[^\"]*\")*[^\"]*$)", -1 ))
		val header = split.first()

		val rdds = split.filter(x => x(0) != header(0))
		
		val schema = StructType( List( 
					StructField( "Id",StringType,true),
					StructField( "Dates",StringType,true),
					StructField( "DayOfWeek",StringType,true),
					StructField( "PdDistrict",StringType,true),
					StructField( "Address",StringType,true),
					StructField( "X",DoubleType,true),
					StructField( "Y",DoubleType,true)
		))

		val test = rdds.map(x => Row(x(0) , x(1), x(2), x(3) , x(4),x(5).toDouble, x(6).toDouble ) )
		
		val df = sqlc.createDataFrame(test, schema)
		
		df
	}


}